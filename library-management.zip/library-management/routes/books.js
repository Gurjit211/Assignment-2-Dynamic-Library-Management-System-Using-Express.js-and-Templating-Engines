/**********************************************************************************
 * ITE5315 – Assignment 2
 * I declare that this assignment is my own work in accordance with Humber Academic Policy.
 * No part of this assignment has been copied manually or electronically from any other source
 * (including websites) or distributed to other students.
 * Name: Gurjit Singh Student ID: N01634963 Date: March 6, 2025
 **********************************************************************************/

const express = require("express");
const fs = require("fs");
const path = require("path");
const multer = require("multer");

const router = express.Router();
const booksFile = path.join(__dirname, "../data/books.json");

// 📌 Multer setup for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "public/uploads/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// 📌 Function to get books
function getBooks() {
    if (!fs.existsSync(booksFile)) return [];
    return JSON.parse(fs.readFileSync(booksFile, "utf8"));
}

// 📌 Function to save books
function saveBooks(books) {
    fs.writeFileSync(booksFile, JSON.stringify(books, null, 4), "utf8");
}

// 📌 Get all books
router.get("/", (req, res) => {
    let books = getBooks();
    const searchQuery = req.query.q;
    if (searchQuery) {
        books = books.filter(book => book.title.toLowerCase().includes(searchQuery.toLowerCase()));
    }
    res.render("books/list", { books, searchQuery, layout: "main" });
});

// 📌 Add New Book (GET)
router.get("/create", (req, res) => {
    res.render("books/form", { mode: "Add", layout: "main" });
});

// 📌 Add New Book (POST)
router.post("/create", upload.single("cover_image"), (req, res) => {
    let books = getBooks();

    // 📌 Validate input fields
    if (!req.body.isbn || !req.body.title || !req.body.author) {
        return res.status(400).render("books/form", { 
            error: "ISBN, Title, and Author are required!", 
            layout: "main" 
        });
    }

    // 📌 Check if ISBN already exists
    if (books.some(book => book.isbn === req.body.isbn)) {
        return res.status(400).render("books/form", { 
            error: "A book with this ISBN already exists!", 
            layout: "main" 
        });
    }

    const newBook = {
        isbn: req.body.isbn,
        title: req.body.title,
        author: req.body.author,
        genre: req.body.genre || "Unknown",
        description: req.body.description || "No description provided.",
        published_year: req.body.published_year ? Number(req.body.published_year) : new Date().getFullYear(),
        status: req.body.status || "AVAILABLE",
        cover_image: req.file ? `/uploads/${req.file.filename}` : "/images/placeholder.png"
    };

    books.push(newBook);
    saveBooks(books);
    res.redirect("/books"); // 📌 Redirect to book list after adding
});

// 📌 Get book details
router.get("/:isbn", (req, res) => {
    const books = getBooks();
    const book = books.find(b => b.isbn === req.params.isbn);
    if (!book) {
        return res.status(404).render("books/details", { error: "Book Not Found", layout: "main" });
    }
    res.render("books/details", { book, layout: "main" });
});

// 📌 Edit Book (GET)
router.get("/:isbn/edit", (req, res) => {
    const books = getBooks();
    const book = books.find(b => b.isbn === req.params.isbn);
    if (!book) {
        return res.status(404).render("books/details", { error: "Book Not Found", layout: "main" });
    }
    res.render("books/form", { book, mode: "Edit", layout: "main" });
});

// 📌 Edit Book (POST)
router.post("/:isbn/edit", upload.single("cover_image"), (req, res) => {
    let books = getBooks();
    const bookIndex = books.findIndex(b => b.isbn === req.params.isbn);

    if (bookIndex === -1) {
        return res.status(404).render("books/form", { error: "Book Not Found", layout: "main" });
    }

    // Update book details
    books[bookIndex].title = req.body.title || books[bookIndex].title;
    books[bookIndex].author = req.body.author || books[bookIndex].author;
    books[bookIndex].genre = req.body.genre || books[bookIndex].genre;
    books[bookIndex].description = req.body.description || books[bookIndex].description;
    books[bookIndex].published_year = req.body.published_year ? Number(req.body.published_year) : books[bookIndex].published_year;
    books[bookIndex].status = req.body.status || books[bookIndex].status;

    // Update cover image if uploaded
    if (req.file) {
        books[bookIndex].cover_image = `/uploads/${req.file.filename}`;
    }

    saveBooks(books);
    res.redirect(`/books/${req.params.isbn}`);
});

// 📌 Delete Book
router.get("/:isbn/delete", (req, res) => {
    let books = getBooks();
    books = books.filter(book => book.isbn !== req.params.isbn);
    saveBooks(books);
    res.redirect("/books");
});

// 📌 Edit Book API (PUT Request)
router.put("/api/books/:isbn/edit", express.json(), (req, res) => {
    let books = getBooks();
    const bookIndex = books.findIndex(b => b.isbn === req.params.isbn);

    // 📌 If book not found, return 404
    if (bookIndex === -1) {
        return res.status(404).json({ error: "Book Not Found" });
    }

    // 📌 Validate required fields
    if (!req.body.title || !req.body.author) {
        return res.status(400).json({ error: "Title and Author are required fields!" });
    }

    // 📌 Update book details
    books[bookIndex] = {
        ...books[bookIndex], // Keep old data
        title: req.body.title,
        author: req.body.author,
        genre: req.body.genre || books[bookIndex].genre,
        description: req.body.description || books[bookIndex].description,
        published_year: req.body.published_year ? Number(req.body.published_year) : books[bookIndex].published_year,
        status: req.body.status || books[bookIndex].status
    };

    //  Save updated book
    saveBooks(books);

    res.json({ message: "Book updated successfully!", book: books[bookIndex] });
});


module.exports = router;
