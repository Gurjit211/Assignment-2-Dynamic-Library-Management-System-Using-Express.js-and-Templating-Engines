/**********************************************************************************
 * ITE5315 – Assignment 2
 * I declare that this assignment is my own work in accordance with Humber Academic Policy.
 * No part of this assignment has been copied manually or electronically from any other source
 * (including websites) or distributed to other students.
 * Name: Gurjit Singh Student ID: N01634963 Date: March 6, 2025
 **********************************************************************************/

const express = require("express");
const exphbs = require("express-handlebars");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

// 📌 Ensure the uploads directory exists
const uploadDir = path.join(__dirname, "public/uploads");
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// 📌 Set up Handlebars with custom helpers
const hbs = exphbs.create({
    extname: ".hbs",
    helpers: {
        eq: (a, b) => a === b,  // ✅ Register 'eq' helper for conditionals
    }
});

app.engine("hbs", hbs.engine);
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "views"));

// 📌 Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// 📌 Import Routes
const booksRoutes = require("./routes/books");
app.use("/books", booksRoutes);

// 📌 Redirect Home to Books List
app.get("/", (req, res) => {
    res.redirect("/books");
});

// 📌 404 Error Handling Middleware (Handles Non-Existent Routes)
app.use((req, res) => {
    res.status(404).render("error", { message: "This route does not exist!", layout: "main" });
});

// 📌 Global Error Handling Middleware (500 Server Errors)
app.use((err, req, res, next) => {
    console.error("🔥 Internal Server Error:", err.stack);
    res.status(500).render("error", { message: "Something went wrong! 500 Server Error.", layout: "main" });
});

// 📌 Start Server
app.listen(PORT, () => console.log(`📚 Library Management running on http://localhost:${PORT}`));
